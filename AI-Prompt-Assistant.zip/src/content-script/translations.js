export const translations = {
  'es': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Portapapeles",
      bookButton: "Libro",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Escribe una pregunta directamente a la AI"
    },
    contextMenu: {
      summaryUrl: "resumen de URL :",
      summaryClipboard: "resumen de Portapapeles :",
      summaryWikipedia: "Buscar en Wikipedia :",
      summaryGoogle: "Buscar en Google :"
    },
    notifications: {
      opening: "Abriendo",
      languageChanged: "Idioma cambiado a:",
      error: "Error al cambiar el idioma"
    },
    settings: {
      title: "Configuración",
      languageLabel: "Idioma de la extensión:",
      aiModelLabel: "Motor de IA:"
    },
    textPrompt: {
      defaultTitle: "Editar prompt",
      cancelButton: "Cancelar",
      acceptButton: "Aceptar",
      bookPrompt: "¿Cuál es el nombre del libro?",
      topicPrompt: "Especificar tema:",
      topicPlaceholder: "Especifique el tema a buscar",
      selectTextClick: "Seleccione y copie el texto de la página y pulse AQUÍ"
    },
    confirmPrompt: {
      title: "Solicitud de acceso",
      message: "¿Permitir el scroll automático para extraer contenido de la página?",
      yesButton: "Sí, permitir",
      noButton: "No, cancelar",
      twitterMessage: "¿Permitir extraer tweets automáticamente de esta página?",
      gmailMessage: "¿Permitir extraer emails automáticamente de esta conversación?"
    }
  },
  'ca': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Portapapers",
      bookButton: "Llibre",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Escriu una pregunta directament a la IA"
    },
    contextMenu: {
      summaryUrl: "resum de URL :",
      summaryClipboard: "resum de Portapapers :",
      summaryWikipedia: "Cercar a Wikipedia :",
      summaryGoogle: "Cercar a Google :"
    },
    notifications: {
      opening: "Obrint",
      languageChanged: "Idioma canviat a:",
      error: "Error en canviar l'idioma"
    },
    settings: {
      title: "Configuració",
      languageLabel: "Idioma de l'extensió:",
      aiModelLabel: "Motor d'IA:"
    },
    textPrompt: {
      defaultTitle: "Editar prompt",
      cancelButton: "Cancel·lar",
      acceptButton: "Acceptar",
      bookPrompt: "Quin és el nom del llibre?",
      topicPrompt: "Especificar tema:",
      topicPlaceholder: "Especifiqueu el tema a cercar",
      selectTextClick: "Seleccioneu i copieu el text de la pàgina i premeu AQUÍ"
    },
    confirmPrompt: {
      title: "Solicitud d'accés",
      message: "Permetre el scroll automàtic per extreure contingut de la pàgina?",
      yesButton: "Sí, permetre",
      noButton: "No, cancel·lar",
      twitterMessage: "Permetre extreure tweets automàticament d'aquesta pàgina?",
      gmailMessage: "Permetre extreure emails automàticament d'aquesta conversació?"
    }
  },
  'gb': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Clipboard",
      bookButton: "Book",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Write a question directly to the AI"
    },
    contextMenu: {
      summaryUrl: "summary of URL :",
      summaryClipboard: "summary of Clipboard :",
      summaryWikipedia: "Search in Wikipedia :",
      summaryGoogle: "Search in Google :"
    },
    notifications: {
      opening: "Opening",
      languageChanged: "Language changed to:",
      error: "Error changing language"
    },
    settings: {
      title: "Settings",
      languageLabel: "Extension language:",
      aiModelLabel: "AI Engine:"
    },
    textPrompt: {
      defaultTitle: "Edit prompt",
      cancelButton: "Cancel",
      acceptButton: "Accept",
      bookPrompt: "What is the name of the book?",
      topicPrompt: "Specify topic:",
      topicPlaceholder: "Please specify the topic to search",
      selectTextClick: "Select and copy the text from the page and click HERE"
    },
    confirmPrompt: {
      title: "Access Request",
      message: "Allow automatic scroll to extract content from the page?",
      yesButton: "Yes, allow",
      noButton: "No, cancel",
      twitterMessage: "Allow automatic extraction of tweets from this page?",
      gmailMessage: "Allow automatic extraction of emails from this conversation?"
    }
  },
  'fr': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Presse-papiers",
      bookButton: "Livre",
      pdfButton: "PDF",
      wikiButton: "Wikipédia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Écrivez une question directement à l'IA"
    },
    contextMenu: {
      summaryUrl: "résumé de URL :",
      summaryClipboard: "résumé de Presse-papiers :",
      summaryWikipedia: "Rechercher dans Wikipedia :",
      summaryGoogle: "Rechercher dans Google :"
    },
    notifications: {
      opening: "Ouverture",
      languageChanged: "Langue changée en:",
      error: "Erreur de changement de langue"
    },
    settings: {
      title: "Paramètres",
      languageLabel: "Langue de l'extension:",
      aiModelLabel: "Moteur IA:"
    },
    textPrompt: {
      defaultTitle: "Modifier le prompt",
      cancelButton: "Annuler",
      acceptButton: "Accepter",
      bookPrompt: "Quel est le nom du livre?",
      topicPrompt: "Spécifier le sujet:",
      topicPlaceholder: "Veuillez spécifier le sujet à rechercher",
      selectTextClick: "Sélectionnez et copiez le texte de la page et cliquez ICI"
    },
    confirmPrompt: {
      title: "Demande d'accès",
      message: "Permettre le défilement automatique pour extraire le contenu de la page?",
      yesButton: "Oui, autoriser",
      noButton: "Non, annuler",
      twitterMessage: "Autoriser l'extraction automatique des tweets de cette page?",
      gmailMessage: "Autoriser l'extraction automatique des emails de cette conversation?"
    }
  },
  'de': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Zwischenablage",
      bookButton: "Bücher",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Schreiben Sie eine Frage direkt an die KI"
    },
    contextMenu: {
      summaryUrl: "Zusammenfassung von URL :",
      summaryClipboard: "Zusammenfassung von Zwischenablage :",
      summaryWikipedia: "Suchen in Wikipedia :",
      summaryGoogle: "Suchen in Google :"
    },
    notifications: {
      opening: "Öffnen",
      languageChanged: "Sprache geändert zu:",
      error: "Fehler beim Ändern der Sprache"
    },
    settings: {
      title: "Einstellungen",
      languageLabel: "Erweiterungssprache:",
      aiModelLabel: "KI-Engine:"
    },
    textPrompt: {
      defaultTitle: "Prompt bearbeiten",
      cancelButton: "Abbrechen",
      acceptButton: "Akzeptieren",
      bookPrompt: "Wie heißt das Buch?",
      topicPrompt: "Thema angeben:",
      topicPlaceholder: "Bitte geben Sie das zu suchende Thema an",
      selectTextClick: "Wählen Sie den Text von der Seite aus, kopieren Sie ihn und klicken Sie HIER"
    },
    confirmPrompt: {
      title: "Zugriffsanfrage",
      message: "Möchten Sie das automatische Scrollen erlauben, um Inhalt von der Seite zu extrahieren?",
      yesButton: "Ja, erlauben",
      noButton: "Nein, abbrechen",
      twitterMessage: "Möchten Sie automatisch Tweets von dieser Seite extrahieren?",
      gmailMessage: "Möchten Sie automatisch E-Mails aus dieser Unterhaltung extrahieren?"
    }
  },
  'it': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Appunti",
      bookButton: "Libro",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Scrivi una domanda direttamente all'IA"
    },
    contextMenu: {
      summaryUrl: "riassunto di URL :",
      summaryClipboard: "riassunto di Appunti :",
      summaryWikipedia: "Cerca in Wikipedia :",
      summaryGoogle: "Cerca in Google :"
    },
    notifications: {
      opening: "Apertura",
      languageChanged: "Lingua cambiata in:",
      error: "Errore durante il cambio della lingua"
    },
    settings: {
      title: "Impostazioni",
      languageLabel: "Lingua dell'estensione:",
      aiModelLabel: "Motore AI:"
    },
    textPrompt: {
      defaultTitle: "Modifica prompt",
      cancelButton: "Annulla",
      acceptButton: "Accetta",
      bookPrompt: "Qual è il nome del libro?",
      topicPrompt: "Specificare argomento:",
      topicPlaceholder: "Si prega di specificare l'argomento da cercare",
      selectTextClick: "Seleziona e copia il testo dalla pagina e clicca QUI"
    },
    confirmPrompt: {
      title: "Richiesta di accesso",
      message: "Permettere lo scroll automatico per estrarre contenuto dalla pagina?",
      yesButton: "Sì, consentire",
      noButton: "No, annullare",
      twitterMessage: "Permettere di estrarre automaticamente i tweet da questa pagina?",
      gmailMessage: "Permettere di estrarre automaticamente i messaggi di posta elettronica da questa conversazione?"
    }
  },
  'ru': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Буфер обмена",
      bookButton: "Книга",
      pdfButton: "PDF",
      wikiButton: "Википедия",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+add+",
      directQuestionButton: "Напишите вопрос напрямую ИИ"
    },
    contextMenu: {
      summaryUrl: "резюме URL :",
      summaryClipboard: "резюме Буфер обмена :",
      summaryWikipedia: "Поиск в Wikipedia :",
      summaryGoogle: "Поиск в Google :"
    },
    notifications: {
      opening: "Открытие",
      languageChanged: "Язык изменен на:",
      error: "Ошибка при изменении языка"
    },
    settings: {
      title: "Настройки",
      languageLabel: "Язык расширения:",
      aiModelLabel: "ИИ двигатель:"
    },
    textPrompt: {
      defaultTitle: "Редактировать промпт",
      cancelButton: "Отмена",
      acceptButton: "Принять",
      bookPrompt: "Как называется книга?",
      topicPrompt: "Указать тему:",
      topicPlaceholder: "Пожалуйста, укажите тему для поиска",
      selectTextClick: "Выберите и скопируйте текст со страницы и нажмите ЗДЕСЬ"
    },
    confirmPrompt: {
      title: "Запрос доступа",
      message: "Разрешить автоматическое прокручивание для извлечения содержимого страницы?",
      yesButton: "Да, разрешить",
      noButton: "Нет, отменить",
      twitterMessage: "Разрешить автоматическое извлечение твитов с этой страницы?",
      gmailMessage: "Разрешить автоматическое извлечение электронных писем из этого разговора?"
    }
  },
  'ar': {
    optionButtons: {
      urlButton: "رابط",
      clipboardButton: "الحافظة",
      bookButton: "كتاب",
      pdfButton: "PDF",
      wikiButton: "ويكيبيديا",
      twitterButton: "تويتر/X",
      gmailButton: "جيميل",
      addButton: "+إضافة+",
      directQuestionButton: "اكتب سؤالاً مباشرة إلى الذكاء الاصطناعي"
    },
    contextMenu: {
      summaryUrl: "ملخص الرابط :",
      summaryClipboard: "ملخص الحافظة :",
      summaryWikipedia: "البحث في ويكيبيديا :",
      summaryGoogle: "البحث في جوجل :"
    },
    notifications: {
      opening: "جاري الفتح",
      languageChanged: "تم تغيير اللغة إلى:",
      error: "خطأ في تغيير اللغة"
    },
    settings: {
      title: "الإعدادات",
      languageLabel: "لغة الإضافة:",
      aiModelLabel: "محرك الذكاء الاصطناعي:"
    },
    textPrompt: {
      defaultTitle: "تحرير الطلب",
      cancelButton: "إلغاء",
      acceptButton: "قبول",
      bookPrompt: "ما اسم الكتاب؟",
      topicPrompt: "تحديد الموضوع:",
      topicPlaceholder: "يرجى تحديد الموضوع للبحث",
      selectTextClick: "حدد وانسخ النص من الصفحة واضغط هنا"
    },
    confirmPrompt: {
      title: "طلب الدخول",
      message: "هل تريد السماح بالتمرير التلقائي لاستخراج المحتوى من الصفحة؟",
      yesButton: "نعم، السماح",
      noButton: "لا، إلغاء",
      twitterMessage: "هل تريد السماح باستخراج التويتات التلقائية من هذه الصفحة؟",
      gmailMessage: "هل تريد السماح باستخراج البريد الإلكتروني التلقائي من هذه المحادثة؟"
    }
  },
  'ja': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "クリップボード",
      bookButton: "ブック",
      pdfButton: "PDF",
      wikiButton: "ウィキペディア",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+追加+",
      directQuestionButton: "AIに直接質問を書く"
    },
    contextMenu: {
      summaryUrl: "URLの要約 :",
      summaryClipboard: "クリップボードの要約 :",
      summaryWikipedia: "Wikipediaで検索 :",
      summaryGoogle: "Googleで検索 :"
    },
    notifications: {
      opening: "開いています",
      languageChanged: "言語が変更されました:",
      error: "言語の変更中にエラーが発生しました"
    },
    settings: {
      title: "設定",
      languageLabel: "拡張機能の言語:",
      aiModelLabel: "AIエンジン:"
    },
    textPrompt: {
      defaultTitle: "プロンプトを編集",
      cancelButton: "キャンセル",
      acceptButton: "受け入れる",
      bookPrompt: "本の名前は何ですか？",
      topicPrompt: "トピックを指定:",
      topicPlaceholder: "検索するトピックを指定してください",
      selectTextClick: "ページからテキストを選択してコピーし、ここをクリック"
    },
    confirmPrompt: {
      title: "アクセスリクエスト",
      message: "ページの内容を自動的にスクロールすることを許可しますか？",
      yesButton: "はい、許可",
      noButton: "いいえ、キャンセル",
      twitterMessage: "このページから自動的にツイートを抽出することを許可しますか？",
      gmailMessage: "この会話から自動的に電子メールを抽出することを許可しますか？"
    }
  },
  'hi': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "क्लिपबोर्ड",
      bookButton: "पुस्तक",
      pdfButton: "PDF",
      wikiButton: "विकिपीडिया",
      twitterButton: "X/ट्विटर",
      gmailButton: "Gmail",
      addButton: "+जोड़ें+",
      directQuestionButton: "AI से सीधे प्रश्न लिखें"
    },
    contextMenu: {
      summaryUrl: "URL का सारांश :",
      summaryClipboard: "क्लिपबोर्ड का सारांश :",
      summaryWikipedia: "विकिपीडिया में खोजें :",
      summaryGoogle: "Google में खोजें :"
    },
    notifications: {
      opening: "खोल रहा है",
      languageChanged: "भाषा बदली गई:",
      error: "भाषा बदलने में त्रुटि"
    },
    settings: {
      title: "सेटिंग्स",
      languageLabel: "एक्सटेंशन भाषा:",
      aiModelLabel: "AI इंजन:"
    },
    textPrompt: {
      defaultTitle: "प्रॉम्प्ट संपादित करें",
      cancelButton: "रद्द करें",
      acceptButton: "स्वीकार करें",
      bookPrompt: "पुस्तक का नाम क्या है?",
      topicPrompt: "विषय निर्दिष्ट करें:",
      topicPlaceholder: "कृपया खोजने के लिए विषय निर्दिष्ट करें",
      selectTextClick: "पृष्ठ से टेक्स्ट चुनें और कॉपी करें और यहाँ क्लिक करें"
    },
    confirmPrompt: {
      title: "अभियान अनुरोध",
      message: "क्या आप एक्सटेंशन को अपने पृष्ठ से सामग्री निकालने के लिए स्वचालित स्क्रॉल करने की अनुमति देना चाहते हैं?",
      yesButton: "हाँ, अनुमति देना",
      noButton: "नहीं, रद्द करना",
      twitterMessage: "क्या आप इस पृष्ठ से स्वचालित रूप से ट्वीट निकालने की अनुमति देना चाहते हैं?",
      gmailMessage: "क्या आप इस बातचीत से स्वचालित रूप से ईमेल निकालने की अनुमति देना चाहते हैं?"
    }
  },
  'kr': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "클립보드",
      bookButton: "책",
      pdfButton: "PDF",
      wikiButton: "위키백과",
      twitterButton: "X/트위터",
      gmailButton: "Gmail",
      addButton: "+추가+",
      directQuestionButton: "AI에게 직접 질문을 작성하세요"
    },
    contextMenu: {
      summaryUrl: "URL 요약 :",
      summaryClipboard: "클립보드 요약 :",
      summaryWikipedia: "위키백과에서 검색 :",
      summaryGoogle: "Google에서 검색 :"
    },
    notifications: {
      opening: "여는 중",
      languageChanged: "언어가 변경되었습니다:",
      error: "언어 변경 오류"
    },
    settings: {
      title: "설정",
      languageLabel: "확장 프로그램 언어:",
      aiModelLabel: "AI 엔진:"
    },
    textPrompt: {
      defaultTitle: "프롬프트 편집",
      cancelButton: "취소",
      acceptButton: "수락",
      bookPrompt: "책의 이름은 무엇입니까?",
      topicPrompt: "주제 지정:",
      topicPlaceholder: "검색할 주제를 지정하십시오",
      selectTextClick: "페이지에서 텍스트를 선택하여 복사하고 여기를 클릭하세요"
    },
    confirmPrompt: {
      title: "접근 요청",
      message: "페이지의 내용을 자동으로 스크롤하여 추출하는 것을 허용하시겠습니까?",
      yesButton: "예, 허용",
      noButton: "아니오, 취소",
      twitterMessage: "이 페이지에서 자동으로 트윗을 추출하는 것을 허용하시겠습니까?",
      gmailMessage: "이 대화에서 자동으로 이메일을 추출하는 것을 허용하시겠습니까?"
    }
  },
  'pt': {
    optionButtons: {
      urlButton: "URL",
      clipboardButton: "Área de transferência",
      bookButton: "Livro",
      pdfButton: "PDF",
      wikiButton: "Wikipedia",
      twitterButton: "X/Twitter",
      gmailButton: "Gmail",
      addButton: "+adicionar+",
      directQuestionButton: "Escreva uma pergunta diretamente para a IA"
    },
    contextMenu: {
      summaryUrl: "resumo de URL :",
      summaryClipboard: "resumo de Área de transferência :",
      summaryWikipedia: "Pesquisar na Wikipedia :",
      summaryGoogle: "Pesquisar no Google :"
    },
    notifications: {
      opening: "Abrindo",
      languageChanged: "Idioma alterado para:",
      error: "Erro ao alterar o idioma"
    },
    settings: {
      title: "Configurações",
      languageLabel: "Idioma da extensão:",
      aiModelLabel: "Motor de IA:"
    },
    textPrompt: {
      defaultTitle: "Editar prompt",
      cancelButton: "Cancelar",
      acceptButton: "Aceitar",
      bookPrompt: "Qual é o nome do livro?",
      topicPrompt: "Especificar tópico:",
      topicPlaceholder: "Por favor, especifique o tópico a pesquisar",
      selectTextClick: "Selecione e copie o texto da página e clique AQUI"
    },
    confirmPrompt: {
      title: "Solicitação de acesso",
      message: "Permitir rolar automaticamente para extrair conteúdo da página?",
      yesButton: "Sim, permitir",
      noButton: "Não, cancelar",
      twitterMessage: "Permitir extrair tweets automaticamente desta página?",
      gmailMessage: "Permitir extrair emails automaticamente desta conversação?"
    }
  },
  'zh': {
    optionButtons: {
      urlButton: "网址",
      clipboardButton: "剪贴板",
      bookButton: "图书",
      pdfButton: "PDF",
      wikiButton: "维基百科",
      twitterButton: "X/推特",
      gmailButton: "Gmail",
      addButton: "+添加+",
      directQuestionButton: "直接向AI写问题"
    },
    contextMenu: {
      summaryUrl: "网址摘要 :",
      summaryClipboard: "剪贴板摘要 :",
      summaryWikipedia: "在维基百科中搜索 :",
      summaryGoogle: "在Google中搜索 :"
    },
    notifications: {
      opening: "正在打开",
      languageChanged: "语言已更改为:",
      error: "更改语言时出错"
    },
    settings: {
      title: "设置",
      languageLabel: "扩展语言:",
      aiModelLabel: "人工智能引擎:"
    },
    textPrompt: {
      defaultTitle: "编辑提示",
      cancelButton: "取消",
      acceptButton: "接受",
      bookPrompt: "书名是什么？",
      topicPrompt: "指定主题:",
      topicPlaceholder: "请指定要搜索的主题",
      selectTextClick: "选择并复制页面中的文本，然后点击这里"
    },
    confirmPrompt: {
      title: "访问请求",
      message: "允许自动滚动以提取页面内容吗？",
      yesButton: "是，允许",
      noButton: "否，取消",
      twitterMessage: "允许自动提取此页面上的推文吗？",
      gmailMessage: "允许自动提取此对话中的电子邮件吗？"
    }
  }
  // Añadir más idiomas según sea necesario...
};

// Función para obtener las traducciones
export function getTranslation(language) {
  return translations[language] || translations['es']; // Inglés como respaldo
}

// Función para actualizar los textos de la interfaz
export function updateUITexts(language) {
  const texts = getTranslation(language);
  
  // Actualizar botones de opción
  const urlButton = document.getElementById('use-url');
  const clipboardButton = document.getElementById('use-clipb');
  const bookButton = document.getElementById('use-book');
  const pdfButton = document.getElementById('use-pdf');
  const wikiButton = document.getElementById('use-wiki');
  const twitterButton = document.getElementById('use-twitter');
  const gmailButton = document.getElementById('use-gmail');
  const addButton = document.getElementById('use-add');
  const directQuestionButton = document.getElementById('direct-question-btn');
  
  if (urlButton) urlButton.textContent = texts.optionButtons.urlButton;
  if (clipboardButton) clipboardButton.textContent = texts.optionButtons.clipboardButton;
  if (bookButton) bookButton.textContent = texts.optionButtons.bookButton;
  if (pdfButton) pdfButton.textContent = texts.optionButtons.pdfButton;
  if (wikiButton) wikiButton.textContent = texts.optionButtons.wikiButton;
  if (twitterButton) twitterButton.textContent = texts.optionButtons.twitterButton;
  if (gmailButton) gmailButton.textContent = texts.optionButtons.gmailButton;
  if (addButton) addButton.textContent = texts.optionButtons.addButton;
  if (directQuestionButton) directQuestionButton.textContent = texts.optionButtons.directQuestionButton;

  // Actualizar textos de configuración
  const settingsTitle = document.querySelector('.popup-header h3');
  const languageLabel = document.querySelector('label[for="language-selector"]');
  const aiModelLabel = document.querySelector('label[for="ai-model-selector"]');
  
  if (settingsTitle) settingsTitle.textContent = texts.settings.title;
  if (languageLabel) languageLabel.textContent = texts.settings.languageLabel;
  if (aiModelLabel) aiModelLabel.textContent = texts.settings.aiModelLabel;
} 